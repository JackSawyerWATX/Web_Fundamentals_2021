
var cookieDiv = document.querySelector(".policy")

function accept() {
    cookieDiv.remove();
}
